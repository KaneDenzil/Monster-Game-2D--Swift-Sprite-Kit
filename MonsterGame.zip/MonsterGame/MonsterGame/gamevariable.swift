

import Foundation

class gamevariable
{
    static var count=0
    static var player1=0
    static var player2=0
    static var flagA=0
    static var flagB=0
    static var normalspeed=0
    static var doublespeed=0
    
}
