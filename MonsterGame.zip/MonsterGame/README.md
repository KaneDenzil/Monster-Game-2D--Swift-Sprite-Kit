# Monster-2
![screen shot 2018-07-26 at 2 45 33 pm](https://user-images.githubusercontent.com/39009985/43281859-bdf04932-90e2-11e8-953b-ad1b40a7e374.png)
![screen shot 2018-07-26 at 2 42 44 pm](https://user-images.githubusercontent.com/39009985/43281860-be020442-90e2-11e8-953a-de8b7f80d84a.png)
![screen shot 2018-07-26 at 2 41 48 pm](https://user-images.githubusercontent.com/39009985/43281861-be11785a-90e2-11e8-9854-981f4cedcf4b.png)
![screen shot 2018-07-26 at 2 41 03 pm](https://user-images.githubusercontent.com/39009985/43281862-be228fa0-90e2-11e8-9c76-2fe9decb15f7.png)
![screen shot 2018-07-26 at 2 41 13 pm](https://user-images.githubusercontent.com/39009985/43281863-be3283d8-90e2-11e8-8b26-a156bae2586e.png)
![screen shot 2018-07-26 at 2 41 27 pm](https://user-images.githubusercontent.com/39009985/43281864-be3f8cb8-90e2-11e8-968a-4da8121434d5.png)
![screen shot 2018-07-26 at 3 01 23 pm](https://user-images.githubusercontent.com/39009985/43282702-d63a65fc-90e4-11e8-8b6b-4fd59f0dd443.png)
